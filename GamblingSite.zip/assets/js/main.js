// JavaScript for site functionality
console.log('Site JS Loaded');